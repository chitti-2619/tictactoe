 Tic Tac Toe is an Material Design offline Android Game<br>
 which can be played by:<br>
 1] Two Players<br>
 2] single player with CPU<br>
 <img src="1.png" width="400" height="700"/>
 <img src="2.png" width="400" height="700"/>
